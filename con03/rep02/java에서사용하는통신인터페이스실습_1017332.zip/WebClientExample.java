package com.example.demo;

import org.springframework.web.reactive.function.client.WebClient;

public class WebClientExample {

    public static void main(String[] args) {
        String apiUrl = "http://share.naver.com/web/shareView";

        WebClient webClient = WebClient.create();
        String response = webClient.get()
                .uri(apiUrl)
                .retrieve()
                .bodyToMono(String.class)
                .block(); // Block until the response is received

        System.out.println("Response from API:\n" + response);
    }
}
