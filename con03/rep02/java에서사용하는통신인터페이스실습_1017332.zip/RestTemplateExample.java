package com.example.demo;

import org.springframework.web.client.RestTemplate;

public class RestTemplateExample {

    public static void main(String[] args) {
        String apiUrl = "http://share.naver.com/web/shareView";

        RestTemplate restTemplate = new RestTemplate();
        String response = restTemplate.getForObject(apiUrl, String.class);

        System.out.println("Response from API:\n" + response);
    }
}
